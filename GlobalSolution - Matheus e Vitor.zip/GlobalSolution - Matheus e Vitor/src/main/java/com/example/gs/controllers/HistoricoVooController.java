package com.example.gs.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.gs.models.Drone;
import com.example.gs.models.HistoricoVoo;
import com.example.gs.models.Telemetria;
import com.example.gs.repositories.DroneRepository;
import com.example.gs.repositories.HistoricoVooRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/historicoVoo")
public class HistoricoVooController {

	@Autowired
	private HistoricoVooRepository historicoVooRepository;

	@Autowired
	private DroneRepository droneRepository;

	@GetMapping("/index")
	public ModelAndView get() {
		ModelAndView model = new ModelAndView("historicoVoo/index");

		List<HistoricoVoo> listaHistoricoVoo = historicoVooRepository.findAll();
		model.addObject("historicoVoos", listaHistoricoVoo);

		return model;

	}

	@GetMapping("/create")
	public String create(Model model) {
		List<Drone> drones = droneRepository.findAll();
		model.addAttribute("drones", drones);
		model.addAttribute("historicoVoo", new HistoricoVoo());
		return "historicoVoo/create";
	}

	@PostMapping("/create")
	public String create(@ModelAttribute("historicoVoo") HistoricoVoo objHistoricoVoo,
			 @RequestParam("idDrone") Long idDrone) {
		HistoricoVoo historicoVoo = new HistoricoVoo();
		historicoVoo.setLatitudeInicioVoo(objHistoricoVoo.getLatitudeInicioVoo());
		historicoVoo.setLatitudeFimVoo(objHistoricoVoo.getLatitudeFimVoo());
		historicoVoo.setLongitudeInicioVoo(objHistoricoVoo.getLongitudeInicioVoo());
		historicoVoo.setLongitudeFimVoo(objHistoricoVoo.getLongitudeFimVoo());
		historicoVoo.setAltitudeMedia(objHistoricoVoo.getAltitudeMedia());
		historicoVoo.setVelocidadeMedia(objHistoricoVoo.getVelocidadeMedia());
		historicoVoo.setDataDecolagem(objHistoricoVoo.getDataDecolagem());
		historicoVoo.setDataAterrisagem(objHistoricoVoo.getDataAterrisagem());

		@SuppressWarnings("unused")
		Drone drone = droneRepository.findById(idDrone)
				.orElseThrow(() -> new IllegalArgumentException("Drone not found"));
		historicoVoo.setIdDrone(idDrone);

		historicoVooRepository.save(historicoVoo);

		return "redirect:/homeLogado";
	}

	@GetMapping("/edit/{id}")
	public String getById(Model model, @PathVariable("id") Long id) {
		HistoricoVoo historicoVoo = historicoVooRepository.findById(id).orElse(null);
		if (historicoVoo == null) {
			
		}

		List<Drone> drones = droneRepository.findAll(); 

		model.addAttribute("historicoVoo", historicoVoo);
		model.addAttribute("drones", drones); 

		return "historicoVoo/edit";
	}

	@PutMapping("/historicoVoo/{id}")
	public ResponseEntity<HistoricoVoo> atualizarDrone(@PathVariable Long id,
			@Valid @RequestBody HistoricoVoo historicoVooAtualizado) {
		HistoricoVoo historicoVoo = historicoVooRepository.findById(id).orElse(null);
		if (historicoVoo == null) {
			
		}

		historicoVoo.setLatitudeInicioVoo(historicoVooAtualizado.getLatitudeInicioVoo());
		historicoVoo.setLatitudeFimVoo(historicoVooAtualizado.getLatitudeFimVoo());
		historicoVoo.setLongitudeInicioVoo(historicoVooAtualizado.getLongitudeInicioVoo());
		historicoVoo.setLongitudeFimVoo(historicoVooAtualizado.getLongitudeFimVoo());
		historicoVoo.setAltitudeMedia(historicoVooAtualizado.getAltitudeMedia());
		historicoVoo.setVelocidadeMedia(historicoVooAtualizado.getVelocidadeMedia());
		historicoVoo.setDataDecolagem(historicoVooAtualizado.getDataDecolagem());
		historicoVoo.setDataAterrisagem(historicoVooAtualizado.getDataAterrisagem());

		final HistoricoVoo historicoVooAtualizadoBD = historicoVooRepository.save(historicoVoo);

		return ResponseEntity.ok(historicoVooAtualizadoBD);
	}

	@PostMapping("/edit/{id}")
	public String update(@PathVariable("id") Long id, @Valid @ModelAttribute("historicoVoo") HistoricoVoo objHistoricoVoo,
			Model model, @RequestParam("idDrone") Long idDrone) {
		HistoricoVoo historicoVoo = historicoVooRepository.findById(id).orElse(null);
		if (historicoVoo == null) {
			
		}

		historicoVoo.setLatitudeInicioVoo(objHistoricoVoo.getLatitudeInicioVoo());
		historicoVoo.setLatitudeFimVoo(objHistoricoVoo.getLatitudeFimVoo());
		historicoVoo.setLongitudeInicioVoo(objHistoricoVoo.getLongitudeInicioVoo());
		historicoVoo.setLongitudeFimVoo(objHistoricoVoo.getLongitudeFimVoo());
		historicoVoo.setAltitudeMedia(objHistoricoVoo.getAltitudeMedia());
		historicoVoo.setVelocidadeMedia(objHistoricoVoo.getVelocidadeMedia());
		historicoVoo.setDataDecolagem(objHistoricoVoo.getDataDecolagem());
		historicoVoo.setDataAterrisagem(objHistoricoVoo.getDataAterrisagem());

		Drone drone = droneRepository.findById(idDrone)
				.orElseThrow(() -> new IllegalArgumentException("Drone not found"));
		historicoVoo.setIdDrone(idDrone);

		historicoVooRepository.save(historicoVoo);

		model.addAttribute("historicoVoo", historicoVoo);

		return "redirect:/homeLogado";
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		historicoVooRepository.deleteById(id);
		return "redirect:/homeLogado";
	}

}
