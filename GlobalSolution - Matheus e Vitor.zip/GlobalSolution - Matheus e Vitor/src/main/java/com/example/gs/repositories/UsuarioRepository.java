package com.example.gs.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gs.models.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

}
