package com.example.gs.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class HistoricoVoo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Long id;

	private Long idDrone;
	private String LatitudeInicioVoo;
	private String LatitudeFimVoo;
	private String LongitudeInicioVoo;
	private String LongitudeFimVoo;
	private String AltitudeMedia;
	private String VelocidadeMedia;
	private String DataDecolagem;
	private String DataAterrisagem;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getIdDrone() {
		return idDrone;
	}
	public void setIdDrone(Long idDrone) {
		this.idDrone = idDrone;
	}
	public String getLatitudeInicioVoo() {
		return LatitudeInicioVoo;
	}
	public void setLatitudeInicioVoo(String latitudeInicioVoo) {
		LatitudeInicioVoo = latitudeInicioVoo;
	}
	public String getLatitudeFimVoo() {
		return LatitudeFimVoo;
	}
	public void setLatitudeFimVoo(String latitudeFimVoo) {
		LatitudeFimVoo = latitudeFimVoo;
	}
	public String getLongitudeInicioVoo() {
		return LongitudeInicioVoo;
	}
	public void setLongitudeInicioVoo(String longitudeInicioVoo) {
		LongitudeInicioVoo = longitudeInicioVoo;
	}
	public String getLongitudeFimVoo() {
		return LongitudeFimVoo;
	}
	public void setLongitudeFimVoo(String longitudeFimVoo) {
		LongitudeFimVoo = longitudeFimVoo;
	}
	public String getAltitudeMedia() {
		return AltitudeMedia;
	}
	public void setAltitudeMedia(String altitudeMedia) {
		AltitudeMedia = altitudeMedia;
	}
	public String getVelocidadeMedia() {
		return VelocidadeMedia;
	}
	public void setVelocidadeMedia(String velocidadeMedia) {
		VelocidadeMedia = velocidadeMedia;
	}
	public String getDataDecolagem() {
		return DataDecolagem;
	}
	public void setDataDecolagem(String dataDecolagem) {
		DataDecolagem = dataDecolagem;
	}
	public String getDataAterrisagem() {
		return DataAterrisagem;
	}
	public void setDataAterrisagem(String dataAterrisagem) {
		DataAterrisagem = dataAterrisagem;
	}
	
	


}
