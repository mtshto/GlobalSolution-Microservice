package com.example.gs.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Drone {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Long id;

	private String modelo;
	private String DataCompra;
	private String CapacidadeBateria;
	private String NumeroSerie;
	private String LicencaVoo;
	private String CapacidadeCarga;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getDataCompra() {
		return DataCompra;
	}

	public void setDataCompra(String dataCompra) {
		DataCompra = dataCompra;
	}

	public String getCapacidadeBateria() {
		return CapacidadeBateria;
	}

	public void setCapacidadeBateria(String capacidadeBateria) {
		CapacidadeBateria = capacidadeBateria;
	}

	public String getNumeroSerie() {
		return NumeroSerie;
	}

	public void setNumeroSerie(String numeroSerie) {
		NumeroSerie = numeroSerie;
	}

	public String getLicencaVoo() {
		return LicencaVoo;
	}

	public void setLicencaVoo(String licencaVoo) {
		LicencaVoo = licencaVoo;
	}

	public String getCapacidadeCarga() {
		return CapacidadeCarga;
	}

	public void setCapacidadeCarga(String capacidadeCarga) {
		CapacidadeCarga = capacidadeCarga;
	}

}
