package com.example.gs.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.gs.models.Drone;
import com.example.gs.models.Telemetria;
import com.example.gs.repositories.DroneRepository;
import com.example.gs.repositories.TelemetriaRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/telemetria")
public class TelemetriaController {

	@Autowired
	private TelemetriaRepository telemetriaRepository;

	@Autowired
	private DroneRepository droneRepository;

	@GetMapping("/index")
	public ModelAndView get() {
		ModelAndView model = new ModelAndView("telemetria/index");

		List<Telemetria> listaTelemetria = telemetriaRepository.findAll();
		model.addObject("telemetrias", listaTelemetria);

		return model;

	}

	@GetMapping("/create")
	public String create(Model model) {
		List<Drone> drones = droneRepository.findAll();
		model.addAttribute("drones", drones);
		model.addAttribute("telemetria", new Telemetria());
		return "telemetria/create";
	}

	@PostMapping("/create")
	public String create(@ModelAttribute("telemetria") Telemetria objTelemetria,
			@RequestParam("DataHora") String DataHora, @RequestParam("idDrone") Long idDrone) {
		Telemetria telemetria = new Telemetria();
		telemetria.setLatitude(objTelemetria.getLatitude());
		telemetria.setLongitude(objTelemetria.getLongitude());
		telemetria.setVelocidade(objTelemetria.getVelocidade());
		telemetria.setDirecao(objTelemetria.getDirecao());
		telemetria.setDataHora(objTelemetria.getDataHora());

		@SuppressWarnings("unused")
		Drone drone = droneRepository.findById(idDrone)
				.orElseThrow(() -> new IllegalArgumentException("Drone not found"));
		telemetria.setIdDrone(idDrone);

		telemetriaRepository.save(telemetria);

		return "redirect:/homeLogado";
	}

	@GetMapping("/edit/{id}")
	public String getById(Model model, @PathVariable("id") Long id) {
		Telemetria telemetria = telemetriaRepository.findById(id).orElse(null);
		if (telemetria == null) {
			
		}

		List<Drone> drones = droneRepository.findAll();

		model.addAttribute("telemetria", telemetria);
		model.addAttribute("drones", drones); 

		return "telemetria/edit";
	}

	@PutMapping("/telemetria/{id}")
	public ResponseEntity<Telemetria> atualizarDrone(@PathVariable Long id,
			@Valid @RequestBody Telemetria telemetriaAtualizado) {
		Telemetria telemetria = telemetriaRepository.findById(id).orElse(null);
		if (telemetria == null) {
			
		}

		telemetria.setLatitude(telemetriaAtualizado.getLatitude());
		telemetria.setLongitude(telemetriaAtualizado.getLongitude());
		telemetria.setVelocidade(telemetriaAtualizado.getVelocidade());
		telemetria.setDirecao(telemetriaAtualizado.getDirecao());
		telemetria.setDataHora(telemetriaAtualizado.getDataHora());

		final Telemetria telemetriaAtualizadoBD = telemetriaRepository.save(telemetria);

		return ResponseEntity.ok(telemetriaAtualizadoBD);
	}

	@PostMapping("/edit/{id}")
	public String update(@PathVariable("id") Long id, @Valid @ModelAttribute("telemetria") Telemetria objTelemetria,
			Model model, @RequestParam("idDrone") Long idDrone) {
		Telemetria telemetria = telemetriaRepository.findById(id).orElse(null);
		if (telemetria == null) {
			
		}

		telemetria.setLatitude(objTelemetria.getLatitude());
		telemetria.setLongitude(objTelemetria.getLongitude());
		telemetria.setVelocidade(objTelemetria.getVelocidade());
		telemetria.setDirecao(objTelemetria.getDirecao());
		telemetria.setDataHora(objTelemetria.getDataHora());

		Drone drone = droneRepository.findById(idDrone)
				.orElseThrow(() -> new IllegalArgumentException("Drone not found"));
		telemetria.setIdDrone(idDrone);

		telemetriaRepository.save(telemetria);

		model.addAttribute("telemetria", telemetria);

		return "redirect:/homeLogado";
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		telemetriaRepository.deleteById(id);
		return "redirect:/homeLogado";
	}

}
