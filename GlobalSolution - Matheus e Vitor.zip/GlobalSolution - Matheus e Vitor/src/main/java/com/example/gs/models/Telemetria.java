package com.example.gs.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class Telemetria  {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String Latitude;
	private String Longitude;
	private String Velocidade;
	private String Direcao;
	private String DataHora;
	
	private Long idDrone; 

	public Long getIdDrone() {
		return idDrone;
	}

	public void setIdDrone(Long idDrone) {
		this.idDrone = idDrone;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLatitude() {
		return Latitude;
	}

	public void setLatitude(String latitude) {
		Latitude = latitude;
	}

	public String getLongitude() {
		return Longitude;
	}

	public void setLongitude(String longitude) {
		Longitude = longitude;
	}

	public String getVelocidade() {
		return Velocidade;
	}

	public void setVelocidade(String velocidade) {
		Velocidade = velocidade;
	}

	public String getDirecao() {
		return Direcao;
	}

	public void setDirecao(String direcao) {
		Direcao = direcao;
	}

	public String getDataHora() {
		return DataHora;
	}

	public void setDataHora(String dataHora) {
		DataHora = dataHora;
	}


	

}