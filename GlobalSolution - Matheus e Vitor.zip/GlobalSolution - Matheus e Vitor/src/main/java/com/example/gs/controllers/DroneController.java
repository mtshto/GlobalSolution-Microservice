package com.example.gs.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.gs.models.Drone;
import com.example.gs.repositories.DroneRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/drone")
public class DroneController {

	@Autowired
	private DroneRepository droneRepository;

	@GetMapping("/index2")
	public ModelAndView getSemLogin() {
		ModelAndView model = new ModelAndView("drone/index2");

		List<Drone> listaDrone = droneRepository.findAll();
		model.addObject("drones", listaDrone);

		return model;

	}
	
	@GetMapping("/index")
	public ModelAndView getComLogin() {
		ModelAndView model = new ModelAndView("drone/index");

		List<Drone> listaDrone = droneRepository.findAll();
		model.addObject("drones", listaDrone);

		return model;

	}

	@GetMapping("/create")
	public String create() {
		return "drone/create";
	}

	@PostMapping("/create")
	public String create(@ModelAttribute("drone") Drone objDrone) {
		Drone drone = new Drone();
		drone.setModelo(objDrone.getModelo());
		drone.setDataCompra(objDrone.getDataCompra());
		drone.setCapacidadeBateria(objDrone.getCapacidadeBateria());
		drone.setNumeroSerie(objDrone.getNumeroSerie());
		drone.setLicencaVoo(objDrone.getLicencaVoo());
		drone.setCapacidadeCarga(objDrone.getCapacidadeCarga());

		droneRepository.save(drone);

		return "redirect:/homeLogado";
	}

	@GetMapping("/edit/{id}")
	public String getById(Model model, @PathVariable("id") Long id) {
		Drone drone = droneRepository.findById(id).orElse(null);
		if (drone == null) {
			
		}

		model.addAttribute("drone", drone);
		return "drone/edit";
	}

	@PutMapping("/edit/{id}")
	public ResponseEntity<Drone> atualizarDrone(@PathVariable Long id, @Valid @RequestBody Drone droneAtualizado) {
		Drone drone = droneRepository.findById(id).orElse(null);
		if (drone == null) {
			
		}

		drone.setModelo(droneAtualizado.getModelo());
		drone.setDataCompra(droneAtualizado.getDataCompra());
		drone.setCapacidadeBateria(droneAtualizado.getCapacidadeBateria());
		drone.setNumeroSerie(droneAtualizado.getNumeroSerie());
		drone.setLicencaVoo(droneAtualizado.getLicencaVoo());

		final Drone droneAtualizadoBD = droneRepository.save(drone);

		return ResponseEntity.ok(droneAtualizadoBD);
	}

	@PostMapping("/edit/{id}")
	public String create(@PathVariable("id") Long id, @ModelAttribute("drone") Drone objDrone, Model model) {
		Drone drone = droneRepository.findById(id).orElse(null);
		if (drone == null) {
		}

		drone.setModelo(objDrone.getModelo());
		drone.setDataCompra(objDrone.getDataCompra());
		drone.setCapacidadeBateria(objDrone.getCapacidadeBateria());
		drone.setNumeroSerie(objDrone.getNumeroSerie());
		drone.setLicencaVoo(objDrone.getLicencaVoo());

		droneRepository.save(drone);

		model.addAttribute("drone", drone);

		return "redirect:/";
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		droneRepository.deleteById(id);
		return "redirect:/";
	}

}
