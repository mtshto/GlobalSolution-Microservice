package com.example.gs.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gs.models.Telemetria;

public interface TelemetriaRepository extends JpaRepository<Telemetria, Long>{

}
