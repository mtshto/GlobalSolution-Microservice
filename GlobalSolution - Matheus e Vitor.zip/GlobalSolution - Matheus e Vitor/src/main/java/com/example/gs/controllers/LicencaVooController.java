package com.example.gs.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.gs.models.Drone;
import com.example.gs.models.LicencaVoo;
import com.example.gs.repositories.DroneRepository;
import com.example.gs.repositories.LicencaVooRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/licencaVoo")
public class LicencaVooController {

	@Autowired
	private LicencaVooRepository LicencaVooRepository;

	@Autowired
	private DroneRepository droneRepository;

	@GetMapping("/index")
	public ModelAndView get() {
		ModelAndView model = new ModelAndView("licencaVoo/index");

		List<LicencaVoo> listaLicencaVoo = LicencaVooRepository.findAll();
		model.addObject("LicencaVoos", listaLicencaVoo);

		return model;
	}

	@GetMapping("/create")
	public String create(Model model) {
		List<Drone> drones = droneRepository.findAll();
		model.addAttribute("drones", drones);
		model.addAttribute("licencaVoo", new LicencaVoo());
		return "LicencaVoo/create";
	}

	@PostMapping("/create")
	public String create(@ModelAttribute("LicencaVoo") LicencaVoo objLicencaVoo,
			@RequestParam("idDrone") Long idDrone) {
		LicencaVoo licencaVoo = new LicencaVoo();
		licencaVoo.setLicencaVoo(objLicencaVoo.getLicencaVoo());
		licencaVoo.setDataValidade(objLicencaVoo.getDataValidade());
		licencaVoo.setDataEmissao(objLicencaVoo.getDataEmissao());

		Drone drone = droneRepository.findById(idDrone)
				.orElseThrow(() -> new IllegalArgumentException("Drone not found"));
		licencaVoo.setIdDrone(idDrone);

		LicencaVooRepository.save(licencaVoo);

		return "redirect:/homeLogado";
	}

	@GetMapping("/edit/{id}")
	public String getById(Model model, @PathVariable("id") Long id) {
		LicencaVoo licencaVoo = LicencaVooRepository.findById(id).orElse(null);
		if (licencaVoo == null) {

		}

		List<Drone> drones = droneRepository.findAll(); // Obtém a lista de drones disponíveis

		model.addAttribute("licencaVoo", licencaVoo);
		model.addAttribute("drones", drones); // Adiciona a lista de drones ao modelo

		return "licencaVoo/edit";
	}

	@PutMapping("/edit/{id}")
	public ResponseEntity<LicencaVoo> atualizarDrone(@PathVariable Long id,
			@Valid @RequestBody LicencaVoo licencaVooAtualizado) {
		LicencaVoo licencaVoo = LicencaVooRepository.findById(id).orElse(null);
		if (licencaVoo == null) {
			
		}

		licencaVoo.setLicencaVoo(licencaVooAtualizado.getLicencaVoo());
		licencaVoo.setDataValidade(licencaVooAtualizado.getDataValidade());
		licencaVoo.setDataEmissao(licencaVooAtualizado.getDataEmissao());

		final LicencaVoo licencaVooAtualizadoBD = LicencaVooRepository.save(licencaVoo);

		return ResponseEntity.ok(licencaVooAtualizadoBD);
	}

	@PostMapping("/edit/{id}")
	public String update(@PathVariable("id") Long id, @Valid @ModelAttribute("licencaVoo") LicencaVoo objLicencaVoo,
			Model model, @RequestParam("idDrone") Long idDrone) {
		LicencaVoo licencaVoo = LicencaVooRepository.findById(id).orElse(null);
		if (licencaVoo == null) {
			
		}

		licencaVoo.setLicencaVoo(objLicencaVoo.getLicencaVoo());
		licencaVoo.setDataValidade(objLicencaVoo.getDataValidade());
		licencaVoo.setDataEmissao(objLicencaVoo.getDataEmissao());

		Drone drone = droneRepository.findById(idDrone)
				.orElseThrow(() -> new IllegalArgumentException("Drone not found"));
		licencaVoo.setIdDrone(idDrone); 

		LicencaVooRepository.save(licencaVoo);

		model.addAttribute("licencaVoo", licencaVoo);

		return "redirect:/homeLogado";
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		LicencaVooRepository.deleteById(id);
		return "redirect:/homeLogado";
	}
}
