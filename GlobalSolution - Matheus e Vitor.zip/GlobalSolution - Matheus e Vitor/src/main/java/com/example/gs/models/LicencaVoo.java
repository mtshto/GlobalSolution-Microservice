package com.example.gs.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class LicencaVoo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String licencaVoo;
	private String DataValidade;
	private String DataEmissao;

	private Long idDrone;

	public Long getIdDrone() {
		return idDrone;
	}

	public void setIdDrone(Long idDrone) {
		this.idDrone = idDrone;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLicencaVoo() {
		return licencaVoo;
	}

	public void setLicencaVoo(String licencaVoo) {
		this.licencaVoo = licencaVoo;
	}

	public String getDataValidade() {
		return DataValidade;
	}

	public void setDataValidade(String dataValidade) {
		DataValidade = dataValidade;
	}

	public String getDataEmissao() {
		return DataEmissao;
	}

	public void setDataEmissao(String dataEmissao) {
		DataEmissao = dataEmissao;
	}

}
