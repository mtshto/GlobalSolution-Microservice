package com.example.gs.controllers;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class UsuarioController {

	@RequestMapping("/login/index")
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login/index");
		return mv;
	}

	@PostMapping("/login")
	public String login(@ModelAttribute("user") User user, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "login/index";
		}

		return "redirect:/homeLogado";
	}

	@RequestMapping("/homeLogado")
	public ModelAndView homeLogado() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("homeLogado");
		return mv;
	}

}
